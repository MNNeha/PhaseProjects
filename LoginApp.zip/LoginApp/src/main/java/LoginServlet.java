import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Simulated authentication (hardcoded values)
        if (email != null && email.equals("demo1@example.com") && password != null && password.equals("password123")) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            response.sendRedirect("Dashboard.html");
        } else {
            response.sendRedirect("Error.html");
        }
    }
}

