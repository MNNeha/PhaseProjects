package com.pg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg.model.Owner;
import com.pg.model.OwnerPlace;
import com.pg.repository.OwnerPlaceRepository;
import com.pg.repository.OwnerRepository;
import com.pg.service.OwnerService;

@Service
public class OwnerServiceImpl implements OwnerService {

 
    private final OwnerRepository ownerRepository;
    @Autowired
    private OwnerPlaceRepository ownerPlaceRepository;
   
    @Autowired
    public OwnerServiceImpl(OwnerRepository ownerRepository) {
        this.ownerRepository = ownerRepository;
   
    }

    @Override
    public Owner findByEmailAndPassword(String ownerEmail, String ownerPassword) {
        return ownerRepository.findByOwnerEmailAndOwnerPassword(ownerEmail, ownerPassword);
    }
    public List<OwnerPlace> getAllOwnerPlaces() {
        return ownerPlaceRepository.findAll();
    }
    
    @Override
    public Owner registerOwner(Owner owner) {
        // Implement registration logic as needed
        return ownerRepository.save(owner);
    }  
    @Override
    public Owner getOwnerById(Long id) {
        return ownerRepository.findById(id).orElse(null);
    }

    @Override
    public Owner findByPgPlaceId(Long pgPlaceId) {
        // Assuming there's a method in your repository to find Owner by PgPlace ID
        return ownerRepository.findByPgPlaceId(pgPlaceId);
    }

	public void saveOwnerPlace(OwnerPlace ownerPlace) {
        ownerPlaceRepository.save(ownerPlace);
    }

}