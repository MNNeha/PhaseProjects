package com.pg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pg.model.Tenant;



public interface TenantRepository extends JpaRepository<Tenant, Long> {
	Tenant findByTenantEmail(String tenantEmail);

	Tenant findByTenantEmailAndTenantPassword(String tenantEmail, String tenantPassword);
}

