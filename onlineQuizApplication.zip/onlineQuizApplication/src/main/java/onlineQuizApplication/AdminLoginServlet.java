package onlineQuizApplication;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class AdminLoginServlet
 */
@WebServlet("/admin")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Hard-coded admin credentials
        String adminUsername = "admin@example.com";
        String adminPassword = "admin123";

        // Retrieve entered credentials from the form
        String enteredUsername = request.getParameter("username");
        String enteredPassword = request.getParameter("password");

        // Create an instance of Admin
        Admin admin = new Admin(adminUsername, adminPassword);

        // Check if entered credentials are valid
        if (admin.authenticate(enteredUsername, enteredPassword)) {
            // Valid credentials, redirect to the admin dashboard
            response.sendRedirect("/admin/dashboard");
        } else {
            // Invalid credentials, redirect back to the login page with an error message
            response.sendRedirect("/admin/login.jsp?error=1");
        }
    }
}
