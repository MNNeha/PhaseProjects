package com.pg.repository;

import org.springframework.data.jpa.repository.JpaRepository; // Add this import
import org.springframework.stereotype.Repository;

import com.pg.model.Owner;



@Repository
public interface OwnerRepository extends JpaRepository<Owner, Long> {
	Owner findByOwnerEmail(String ownerEmail);
	Owner findByOwnerEmailAndOwnerPassword(String ownerEmail, String ownerPassword);
	Owner findByPgPlaceId(Long pgPlaceId);
}
