package com.pg.service;


import com.pg.model.Enquiry;

import java.util.List;

public interface EnquiryService {
    List<Enquiry> getAllEnquiries();
}
