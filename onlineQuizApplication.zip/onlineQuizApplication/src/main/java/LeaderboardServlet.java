import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import onlineQuizApplication.DataBaseConnection;
import onlineQuizApplication.LeaderboardEntry;


public class LeaderboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Fetch leaderboard data from the database
        List<LeaderboardEntry> leaderboard = retrieveLeaderboardDataFromDatabase();

        // Set leaderboard data as request attribute
        request.setAttribute("leaderboard", leaderboard);

        // Forward the request to the leaderboard.jsp page
        request.getRequestDispatcher("/leaderboard.jsp").forward(request, response);
    }

    // Method to retrieve leaderboard data from the database
    private List<LeaderboardEntry> retrieveLeaderboardDataFromDatabase() {
        List<LeaderboardEntry> leaderboard = new ArrayList<>();

        // Database connection and query to retrieve leaderboard data
        try (Connection connection = DataBaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM results ORDER BY score DESC")) {

            int rank = 1;

            while (resultSet.next()) {
                int userId = resultSet.getInt("user_id");
                int score = resultSet.getInt("score");

                // Create a LeaderboardEntry object and add it to the list
                LeaderboardEntry entry = new LeaderboardEntry(rank++, userId, score);
                leaderboard.add(entry);
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        return leaderboard;
    }
}
