import java.io.IOException;

import com.example.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public class DisplayProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the product from the session
        HttpSession session = request.getSession();
        Product product = (Product) session.getAttribute("product");

        // Set the product attribute for the JSP page
        request.setAttribute("product", product);

        // Forward the request to the display JSP page
        request.getRequestDispatcher("display.jsp").forward(request, response);
    }
}

