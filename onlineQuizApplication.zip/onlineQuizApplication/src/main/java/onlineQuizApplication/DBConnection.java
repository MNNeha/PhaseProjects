package onlineQuizApplication;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBConnection {
	public static Connection getConnection() throws SQLException {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found", e);
        }

        // Replace 'your_username', 'your_password', and 'quizdb' with your actual credentials and database name
        String url = "jdbc:mysql://localhost:3306/quizdb";
        String username = "root";
        String password = "Tiger#779569";

        return DriverManager.getConnection(url, username, password);
    }
}
