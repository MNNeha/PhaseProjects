package com.pg.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "enquiry")
public class Enquiry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pg_place_id")
    private PGPlace pgPlace;

    private String name;

    private String status;

 // Constructors

    public Enquiry() {
    }

    public Enquiry(PGPlace pgPlace, String name, String status) {
        this.pgPlace = pgPlace;
        this.name = name;
        this.status = status;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public PGPlace getPgPlace() {
        return pgPlace;
    }

    public void setPgPlace(PGPlace pgPlace) {
        this.pgPlace = pgPlace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
