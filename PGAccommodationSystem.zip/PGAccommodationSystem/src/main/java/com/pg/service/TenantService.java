package com.pg.service;

import com.pg.model.Tenant;

public interface TenantService {

    Tenant findByEmailAndPassword(String tenantEmail, String tenantPassword);

    void saveTenant(Tenant tenant);
}