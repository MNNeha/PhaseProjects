package com.pg.model;

import java.math.BigDecimal;

public class PlaceForm {

    private String placeName;
    private String placeAddress;
    private String city;
    private BigDecimal placeRent;

    // Getter methods
    public String getPlaceName() {
        return placeName;
    }

    public String getPlaceAddress() {
        return placeAddress;
    }

    public String getCity() {
        return city;
    }

    public BigDecimal getPlaceRent() {
        return placeRent;
    }

    // Setter methods
    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public void setPlaceAddress(String placeAddress) {
        this.placeAddress = placeAddress;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setPlaceRent(BigDecimal placeRent) {
        this.placeRent = placeRent;
    }
}
