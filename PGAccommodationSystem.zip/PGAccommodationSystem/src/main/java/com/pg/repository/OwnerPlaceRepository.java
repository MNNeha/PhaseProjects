package com.pg.repository;

import com.pg.model.OwnerPlace;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OwnerPlaceRepository extends JpaRepository<OwnerPlace, Long> {
	// Inside OwnerPlaceRepository
	List<OwnerPlace> findByCity(String city);
	
}
