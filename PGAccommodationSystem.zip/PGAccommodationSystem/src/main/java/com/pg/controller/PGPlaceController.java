package com.pg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pg.model.Owner;
import com.pg.model.PGPlace;
import com.pg.service.OwnerService;
import com.pg.service.PGPlaceService;

import java.util.List;

@Controller
@RequestMapping("/pg")
public class PGPlaceController {

    @Autowired
    private PGPlaceService pgPlaceService;
    @Autowired
    private OwnerService ownerService;
    @GetMapping("/places")
    public String getPGPlaces(@RequestParam(name = "locality", required = false, defaultValue = "") String locality, Model model) {
        List<PGPlace> searchResults;

        if (locality.isEmpty()) {
            // If locality is empty, fetch all PG places
            searchResults = pgPlaceService.getAllPGPlaces();
        } else {
            // If locality is provided, fetch PG places by locality
            searchResults = pgPlaceService.findPGPlacesByCity(locality);
        }

        model.addAttribute("searchResults", searchResults);
        model.addAttribute("totalRecords", searchResults.size());
        return "pg_places_search_result";
    }
    @GetMapping("/details/{id}")
    public String showPgPlaceDetails(@PathVariable Long id, Model model) {
        PGPlace pgPlace = pgPlaceService.getPGPlaceById(id);

        if (pgPlace == null) {
            // Handle the case when PG place is not found
            return "pg_place_not_found_error";
        }

        // Add PG place to the model
        model.addAttribute("pgPlace", pgPlace);

        return "pg_place_details";
    }

}