package com.pg.controller;

import com.pg.service.EnquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EnquiryController {

    @Autowired
    private EnquiryService enquiryService;

    @GetMapping("/pg/enquiries")
    public String showEnquiries(Model model) {
        model.addAttribute("enquiries", enquiryService.getAllEnquiries());
        return "enquiries";
    }
}