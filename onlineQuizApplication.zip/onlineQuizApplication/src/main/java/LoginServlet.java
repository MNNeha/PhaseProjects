import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Perform login operation (authentication) here...

        // For demonstration purposes, let's simulate user registration and show success message
        registerUser(email, password);

        // Set success message attribute
        request.setAttribute("successMessage", "Account created successfully!");

        // Forward the request to the JSP page
        request.getRequestDispatcher("/student_login.jsp").forward(request, response);
    }

    private void registerUser(String email, String password) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            String url = "jdbc:mysql://localhost:3306/online_quiz"; // Update with your database details
            String username = "root";
            String dbPassword = "Tiger#779569";
            Connection connection = DriverManager.getConnection(url, username, dbPassword);

            // Insert user into the database (for demonstration purposes)
            String sql = "INSERT INTO users (email, password) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, password);
                preparedStatement.executeUpdate();
            }

            // Close the database connection
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
