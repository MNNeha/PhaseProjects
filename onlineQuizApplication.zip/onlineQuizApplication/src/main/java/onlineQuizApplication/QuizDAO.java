package onlineQuizApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QuizDAO {
	 private static final String JDBC_URL = "jdbc:mysql://localhost:3306/quizdb";
	    private static final String USERNAME = "root";
	    private static final String PASSWORD = "Tiger#779569";

	    // Method to retrieve quiz data from the database
	    public List<Quiz> retrieveQuizDataFromDatabase() {
	        List<Quiz> quizList = new ArrayList<>();

	        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
	             PreparedStatement statement = connection.prepareStatement("SELECT * FROM quizzes");
	             ResultSet resultSet = statement.executeQuery()) {

	            while (resultSet.next()) {
	                int id = resultSet.getInt("id");
	                String title = resultSet.getString("title");
	                String category = resultSet.getString("category");

	                // Create a Quiz object and add it to the list
	                Quiz quiz = new Quiz(id, title, category);
	                quizList.add(quiz);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace(); // Handle the exception appropriately
	        }

	        return quizList;
	    }
}
