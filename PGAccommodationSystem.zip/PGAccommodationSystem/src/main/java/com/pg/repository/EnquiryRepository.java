package com.pg.repository;

import com.pg.model.Enquiry;
import com.pg.model.PGPlace;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnquiryRepository extends JpaRepository<Enquiry, Long> {

    // Custom query method to find enquiries by status
    List<Enquiry> findByStatus(String status);

}