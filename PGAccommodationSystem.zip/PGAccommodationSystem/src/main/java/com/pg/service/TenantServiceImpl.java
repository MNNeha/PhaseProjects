package com.pg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg.model.Tenant;
import com.pg.repository.TenantRepository;

@Service
public class TenantServiceImpl implements TenantService {

    private final TenantRepository tenantRepository;

    @Autowired
    public TenantServiceImpl(TenantRepository tenantRepository) {
        this.tenantRepository = tenantRepository;
    }

    @Override
    public Tenant findByEmailAndPassword(String tenantEmail, String tenantPassword) {
        return tenantRepository.findByTenantEmailAndTenantPassword(tenantEmail, tenantPassword);
    }

    @Override
    public void saveTenant(Tenant tenant) {
        tenantRepository.save(tenant);
    }
}
