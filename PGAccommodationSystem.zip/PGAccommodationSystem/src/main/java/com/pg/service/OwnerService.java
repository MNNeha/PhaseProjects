package com.pg.service;

import com.pg.model.Owner;
import com.pg.model.PlaceForm;


public interface OwnerService {
    
	 Owner registerOwner(Owner owner);


	Owner findByPgPlaceId(Long id);

	Owner getOwnerById(Long id);
	


	Owner findByEmailAndPassword(String ownerEmail, String ownerPassword);


	Owner saveOwner(Owner owner);
	Owner saveOwnerPlace(PlaceForm placeForm);


}
