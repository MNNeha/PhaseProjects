package com.pg.service;

import com.pg.model.Enquiry;
import com.pg.repository.EnquiryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnquiryServiceImpl implements EnquiryService {

    @Autowired
    private EnquiryRepository enquiryRepository;

    @Override
    public List<Enquiry> getAllEnquiries() {
        return enquiryRepository.findAll();
    }
}