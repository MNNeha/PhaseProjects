package onlineQuizApplication;
public class Admin {
    private String username;
    private String password;

    public Admin(String username, String password) {
        this.username = username;
        this.password = password;
    }

    

    public boolean authenticate(String enteredUsername, String enteredPassword) {
        // Basic authentication logic
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }
}
