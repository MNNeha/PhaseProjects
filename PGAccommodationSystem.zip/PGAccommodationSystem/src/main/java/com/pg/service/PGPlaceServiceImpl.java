package com.pg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.pg.model.PGPlace;
import com.pg.repository.PGPlaceRepository;

@Service
public class PGPlaceServiceImpl implements PGPlaceService {

    @Autowired
    private PGPlaceRepository pgPlaceRepository;

    @Override
    public List<PGPlace> getAllPGPlaces() {
        return pgPlaceRepository.findAll();
    }

    @Override
    public PGPlace getPGPlaceById(Long id) {
        return pgPlaceRepository.findById(id).orElse(null);
    }

    @Override
    public void savePGPlace(PGPlace pgPlace) {
        pgPlaceRepository.save(pgPlace);
    }

    @Override
    public void deletePGPlaceById(Long id) {
        pgPlaceRepository.deleteById(id);
    }

    @Override
    public List<PGPlace> findPGPlacesByCity(String city) {
        return pgPlaceRepository.findPGPlacesByCity(city);
    }
}
