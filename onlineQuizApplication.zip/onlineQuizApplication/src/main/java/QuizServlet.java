import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import onlineQuizApplication.Quiz;
import onlineQuizApplication.QuizDAO;


public class QuizServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve quiz details from the database
    	 List<Quiz> quizList = new QuizDAO().retrieveQuizDataFromDatabase();
    	
        // Set retrieved data as request attributes
        request.setAttribute("quizList", quizList);

        // Forward the request to the JSP page
        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }

 
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle form submission, update or delete quiz details in the database
        // Perform necessary database operations using JDBC

        // Redirect back to the dashboard
        response.sendRedirect(request.getContextPath() + "/QuizServlet");
    }
}
