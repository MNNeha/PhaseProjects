package com.pg.controller;

import com.pg.model.Owner;
import com.pg.model.PlaceForm;
import com.pg.repository.OwnerPlaceRepository;
import com.pg.service.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/owner")
public class OwnerController {

    @Autowired
    
    private OwnerService ownerService;
    @Autowired
    private OwnerPlaceRepository ownerPlaceRepository;
    @GetMapping("/login")
    public String showLoginForm() {
        return "owner_login";
    }
    @PostMapping("/login")
    public String processLogin(@RequestParam String ownerEmail, @RequestParam String ownerPassword, Model model) {
        Owner owner = ownerService.findByEmailAndPassword(ownerEmail, ownerPassword);

        if (owner != null) {
            // Tenant authentication successful
            model.addAttribute("ownerName", owner.getOwnerName());
            return "redirect:/owner/places";  // Redirect to PG places after successful login
        } else {
            // Invalid credentials
            model.addAttribute("error", "Invalid credentials! Please try again.");
            return "owner_login";
        }
    }

    @GetMapping("/registration")
    public String showRegistrationForm(Model model) {
        model.addAttribute("owner", new Owner());
        return "owner_registration";
    }

    @PostMapping("/registration")
    public String processRegistration(@ModelAttribute Owner owner) {
        ownerService.saveOwner(owner);
        return "redirect:/owner/login";
    }
    @GetMapping("/places/add-new")
    public String showAddNewPlaceForm(Model model) {
        model.addAttribute("placeForm", new PlaceForm());
        return "owner_add_new_place";
    }

    @PostMapping("/places/add-new")
    public String processAddNewPlace(@ModelAttribute PlaceForm placeForm) {
        // Assuming you have a method in OwnerService to save a new owner place
        ownerService.saveOwnerPlace(placeForm);
        return "redirect:/owner/places";
    }

    @GetMapping("/{id}")
    public ResponseEntity<Owner> getOwnerById(@PathVariable Long id) {
        Owner owner = ownerService.getOwnerById(id);

        if (owner != null) {
            return ResponseEntity.ok(owner);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
