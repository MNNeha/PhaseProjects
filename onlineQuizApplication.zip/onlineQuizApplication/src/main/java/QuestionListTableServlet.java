import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import onlineQuizApplication.DBConnection;
import onlineQuizApplication.Question;

public class QuestionListTableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve question details from the database
        List<Question> questionList = retrieveQuestionDataFromDatabase();

        // Set retrieved data as request attributes
        request.setAttribute("questionList", questionList);

        // Forward the request to the JSP page for rendering
        request.getRequestDispatcher("/questionListTable.jsp").forward(request, response);
    }

    private List<Question> retrieveQuestionDataFromDatabase() {
        List<Question> questionList = new ArrayList<>();

        // Fetch data from the 'questions' table using JDBC
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM questions");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String question = resultSet.getString("question");
                String option1 = resultSet.getString("option1");
                String option2 = resultSet.getString("option2");
                String option3 = resultSet.getString("option3");
                String option4 = resultSet.getString("option4");
                String correct_option = resultSet.getString("correct_option");

                // Create a Question object and add it to the list
                Question questionObj = new Question(id, question, option1, option2, option3, option4, correct_option);
                questionList.add(questionObj);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        return questionList;
    }
}
