import java.io.IOException;

import com.example.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public class ProductFormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Capture form data
        String productName = request.getParameter("productName");
        double price = Double.parseDouble(request.getParameter("price"));

        // Create a Product object and set the values
        Product product = new Product();
        product.setProductName(productName);
        product.setPrice(price);

        // Store the product object in the session
        HttpSession session = request.getSession();
        session.setAttribute("product", product);

        // Redirect to the display page
        response.sendRedirect("display.jsp");

    }
}
