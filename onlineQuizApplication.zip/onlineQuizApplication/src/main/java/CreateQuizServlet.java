import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import onlineQuizApplication.DBConnection;


public class CreateQuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve quiz details from the form
        String quizTitle = request.getParameter("quizTitle");
        String category = request.getParameter("category");

        // Perform necessary database operations to create a new quiz using JDBC
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO quizzes (title, category) VALUES (?, ?)")) {

            preparedStatement.setString(1, quizTitle);
            preparedStatement.setString(2, category);

            // Execute the query to insert a new quiz
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        // Redirect back to the dashboard or any other appropriate page
        response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
    }
}

