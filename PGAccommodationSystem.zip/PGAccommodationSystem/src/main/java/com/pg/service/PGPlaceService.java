package com.pg.service;

import java.util.List;

import com.pg.model.PGPlace;

public interface PGPlaceService {
    List<PGPlace> getAllPGPlaces();
    PGPlace getPGPlaceById(Long id);
    void savePGPlace(PGPlace pgPlace);
    void deletePGPlaceById(Long id);
	List<PGPlace> findPGPlacesByCity(String city);
	PGPlace findById(Long id);

}
