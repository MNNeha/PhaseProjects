package onlineQuizApplication;

public class LeaderboardEntry {
	  private int rank;
	    private int userId;
	    private int score;

	    public LeaderboardEntry(int rank, int userId, int score) {
	        this.rank = rank;
	        this.userId = userId;
	        this.score = score;
	    }

	    public int getRank() {
	        return rank;
	    }

	    public int getUserId() {
	        return userId;
	    }

	    public int getScore() {
	        return score;
	    }
}
