import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import onlineQuizApplication.DBConnection;
import onlineQuizApplication.DataBaseConnection;
import onlineQuizApplication.Quiz;

public class QuizListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Establish a connection to the database
            try (Connection connection = DataBaseConnection.getConnection()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM userquiz");

                // Create a list to store quiz data
                List<Quiz> quizList = new ArrayList<>();

                // Iterate over the result set and populate the quiz list
                while (resultSet.next()) {
                    int srno = resultSet.getInt("srno");
                    String quizTitle = resultSet.getString("quiz_title");
                    String category = resultSet.getString("category");

                    // Create a Quiz object and add it to the list
                    Quiz quiz = new Quiz(srno, quizTitle, category);
                    quizList.add(quiz);
                }

                // Set the quizList as a request attribute
                request.setAttribute("quizList", quizList);

                // Forward the request to the JSP page
                request.getRequestDispatcher("/quizlist.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            // Log the exception
            e.printStackTrace();

            // Handle the exception appropriately, e.g., show an error page
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
        }
    }
}

