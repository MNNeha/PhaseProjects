package com.example.authentication;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AuthenticationTest {

    @Test
    public void testAuthenticateUser() {
        com.example.authentication.Authentication auth = new com.example.authentication.Authentication();

        // Valid authentication
        boolean result = auth.authenticateUser("testuser", "password123");
        assertTrue("Authentication failed", result);

        // Invalid authentication
        boolean invalidresult = auth.authenticateUser("user", "password123");
        assertFalse( "Invalid authentication passed", invalidresult);
    }
}
