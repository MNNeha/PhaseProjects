package com.pg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.pg.model.Tenant;
import com.pg.service.TenantService;

@Controller
@RequestMapping("/pg")
public class TenantController {

    @Autowired
    @Qualifier("tenantServiceImpl")
    private TenantService tenantService;

    @GetMapping("/tenantlogin")
    public String showLoginForm() {
        return "tenant_login";
    }

    @PostMapping("/tenantlogin")
    public String processLogin(@RequestParam String tenantEmail, @RequestParam String tenantPassword, Model model) {
        Tenant tenant = tenantService.findByEmailAndPassword(tenantEmail, tenantPassword);

        if (tenant != null) {
            // Tenant authentication successful
            model.addAttribute("tenantName", tenant.getTenantName());
            return "redirect:/pg/places?locality=";  // Redirect to PG places after successful login
        } else {
            // Invalid credentials
            model.addAttribute("error", "Invalid credentials! Please try again.");
            return "tenant_login";
        }
    }


    @GetMapping("/registration")
    public String showRegistrationForm(Model model) {
        model.addAttribute("tenant", new Tenant());
        return "tenant_registration";
    }

    @PostMapping("/registration")
    public String processRegistration(@ModelAttribute Tenant tenant) {
        tenantService.saveTenant(tenant);
        return "redirect:/pg/tenantlogin";
    }
}